**Le Brandubh est un ancien jeu de plateau irlandais qui se joue sur un plateau de 7x7 cases. Le jeu oppose deux joueurs, l'un jouant les pièces rouges et l'autre les pièces noires. Les pièces rouges (attaquants) commencent toujours.**

**__ - MATÉRIEL -__**
🔲  1 plateau de jeu, 8 soldats rouges (les attaquants), 4 soldats noirs (les défenseurs), 1 branán (roi).

**__- BUT DU JEU -__**
⬜  Les attaquants doivent capturer le branán. Les défenseurs doivent emmener leur branán dans un des coins du plateau. Les coins réprésentent des villes.

**__ - COMMENT JOUER -__**
🟩 Les soldats et le branán se déplacent tous horizontalement ou verticalement, d’autant de cases que voulues. Il est interdit de sauter par-dessus un pion ou la case centrale. La case centrale est strictement interdite à tous les soldats. Seul le branán commence sur cette case : c’est son trône.
Mais attention, une fois le roi déscendu de son trône, il ne pourra plus y rentrer !

**__ - DÉROULEMENT DU JEU -__**
🟪 La prise d’un soldat adverse se fait par encadrement. Lorsqu’un pion est cerné sur deux bords opposés (droite et gauche OU haut et bas), il est capturé. Si le trône est libre, un soldat peut être capturé entre un soldat adverse et le trône.
Un soldat peut également être capturé entre un soldat adverse et n'importe lequel des coins.

**__ - PARTICULARITÉ - __**
🟧 Tout soldat allant volontairement entre deux ennemis n’est pas capturé. La prise est toujours le résultat d’une attaque.

**__- FIN DU JEU -__**
🟥  Si le branán est sur son trône, alors la capture de celui-ci est réussie avec 4 soldats (un sur chaque bord). Sinon, seul 2 soldats suffisent (encadrement). Les attaquants gagnent ainsi la partie.
Le branán lui doit atteindre un des coins du plateau pour assurer la victoire aux défenseurs.